import './init/app_init.dart';

//程序的主入口
void main() => AppInit.run();








